<p align="center">
    <a href="https://github.com/SN-Abdullah-Al-Noman/Atrocious_Mirror">
        <kbd>
            <img width="250" src="https://telegra.ph/file/440254850680056bbeb3a.jpg" alt="SN-Abdullah-Al-Noman Logo">
        </kbd>
    </a>
</p>

<p align="center">
<div align=center>

[![GitHub forks](https://img.shields.io/github/forks/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=social)](https://github.com/SN-Abdullah-Al-Noman/Atrocious_Mirror/fork)
[![GitHub followers](https://img.shields.io/github/followers/SN-Abdullah-Al-Noman?style=social&label=SN-Abdullah-Al-Noman%20Followers)](https://github.com/SN-Abdullah-Al-Noman)

----

[![](https://img.shields.io/github/repo-size/SN-Abdullah-Al-Noman/Atrocious_Mirror?color=green&label=Repo%20Size&labelColor=292c3b)](#) [![](https://img.shields.io/github/commit-activity/m/SN-Abdullah-Al-Noman/Atrocious_Mirror?logo=github&labelColor=292c3b&label=Github%20Commits)](#) [![](https://img.shields.io/github/license/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=License&labelColor=292c3b)](#)|[![](https://img.shields.io/github/issues-raw/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Open%20Issues&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-closed-raw/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Closed%20Issues&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-pr-raw/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Open%20Pull%20Requests&labelColor=292c3b)](#) [![](https://img.shields.io/github/issues-pr-closed-raw/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Closed%20Pull%20Requests&labelColor=292c3b)](#)
:---:|:---:|
[![](https://img.shields.io/github/languages/count/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Total%20Languages&labelColor=292c3b&color=blueviolet)](#) [![](https://img.shields.io/github/languages/top/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&logo=python&labelColor=292c3b)](#) [![](https://img.shields.io/github/last-commit/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&label=Last%20Commit&labelColor=292c3b&color=important)](#) [![](https://badgen.net/github/branches/SN-Abdullah-Al-Noman/Atrocious_Mirror?label=Total%20Branches&labelColor=292c3b)](#)|[![](https://img.shields.io/github/forks/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&logo=github&label=Forks&labelColor=292c3b&color=critical)](#) [![](https://img.shields.io/github/stars/SN-Abdullah-Al-Noman/Atrocious_Mirror?style=flat&logo=github&label=Stars&labelColor=292c3b&color=yellow)](#) [![](https://hub.docker.com/repository/docker/pulls/noman12/snwzmlsync?icon=docker&label=Pulls&labelColor=292c3b&color=blue)](#)
[![](https://img.shields.io/badge/Telegram%20Channel-Join-9cf?style=for-the-badge&logo=telegram&logoColor=blue&style=flat&labelColor=292c3b)](https://t.me/SN-Abdullah-Al-Noman_update) |[![](https://img.shields.io/badge/Support%20Group-Join-9cf?style=for-the-badge&logo=telegram&logoColor=blue&style=flat&labelColor=292c3b)](https://t.me/AtrociousBotSupport) |

</div>

----
